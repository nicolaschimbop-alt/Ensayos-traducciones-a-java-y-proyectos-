/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
public class Ejercicio02 {
    public static void main(String[] args) {
        mostrarPares();
    }
    
    // Metodo sin parametros y sin retorno
    public static void mostrarPares() {
        System.out.println("Numeros pares del 2 al 100:");
        for (int i = 2; i <= 100; i += 2) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}