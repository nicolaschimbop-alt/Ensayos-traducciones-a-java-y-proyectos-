/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese un numero entero: ");
            int numero = sc.nextInt();
            if (esPar(numero)) {
                System.out.println("true");
            } else {
                System.out.println("false");
            }
        }
    }
    
    // Metodo con parametros y con retorno
    public static boolean esPar(int numero) {
        return numero % 2 == 0;
    }
}