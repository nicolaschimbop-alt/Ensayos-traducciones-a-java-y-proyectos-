/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
public class Ejercicio01 {
    public static void main(String[] args) {
        bienvenida();
    }
    
    // Metodo sin parametros y sin retorno
    public static void bienvenida() {
        System.out.println("Universidad: Universidad Tecnica de Machala");
        System.out.println("Materia: Tecnicas de Programacion");
        System.out.println("Estudiante: [Mathias Nicolas Chimbo Pereira]");
    }
}