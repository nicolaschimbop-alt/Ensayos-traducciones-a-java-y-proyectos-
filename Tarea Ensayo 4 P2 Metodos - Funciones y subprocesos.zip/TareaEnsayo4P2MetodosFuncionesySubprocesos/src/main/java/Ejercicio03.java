/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio03 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese su nombre: ");
            String nombre = sc.nextLine();
            saludar(nombre);
        }
    }
    
    // Metodo con parametro y sin retorno
    public static void saludar(String nombre) {
        System.out.println("Bienvenido " + nombre);
    }
}