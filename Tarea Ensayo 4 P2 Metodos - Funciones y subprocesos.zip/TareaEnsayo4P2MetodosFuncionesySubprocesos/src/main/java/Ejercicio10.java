/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese el primer numero: ");
            int a = sc.nextInt();
            System.out.print("Ingrese el segundo numero: ");
            int b = sc.nextInt();
            int mayor = mayor(a, b);
            System.out.println("El numero mayor es: " + mayor);
        }
    }
    
    // Metodo con parametros y con retorno
    public static int mayor(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }
}