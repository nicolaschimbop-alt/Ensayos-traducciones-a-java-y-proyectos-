/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio08 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese la base del rectangulo: ");
            double base = sc.nextDouble();
            System.out.print("Ingrese la altura del rectangulo: ");
            double altura = sc.nextDouble();
            double area = calcularArea(base, altura);
            System.out.println("El area del rectangulo es: " + area);
        }
    }
    
    // Metodo con parametros y con retorno
    public static double calcularArea(double base, double altura) {
        return base * altura;
    }
}