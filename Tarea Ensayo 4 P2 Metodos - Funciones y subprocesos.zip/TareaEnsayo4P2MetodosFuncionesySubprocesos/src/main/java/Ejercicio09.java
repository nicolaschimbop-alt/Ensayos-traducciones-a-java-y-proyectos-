/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio09 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese la primera nota: ");
            double n1 = sc.nextDouble();
            System.out.print("Ingrese la segunda nota: ");
            double n2 = sc.nextDouble();
            System.out.print("Ingrese la tercera nota: ");
            double n3 = sc.nextDouble();
            double promedio = calcularPromedio(n1, n2, n3);
            System.out.println("El promedio es: " + promedio);
            if (promedio >= 7) {
                System.out.println("Estudiante aprobado.");
            } else {
                System.out.println("Estudiante reprobado.");
            }
        }
    }
    
    // Metodo con parametros y con retorno
    public static double calcularPromedio(double n1, double n2, double n3) {
        return (n1 + n2 + n3) / 3;
    }
}