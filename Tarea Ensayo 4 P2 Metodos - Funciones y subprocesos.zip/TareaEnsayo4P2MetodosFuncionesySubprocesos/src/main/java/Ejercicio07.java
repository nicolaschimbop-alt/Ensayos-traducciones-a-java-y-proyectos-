/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
public class Ejercicio07 {
    public static void main(String[] args) {
        double pi = obtenerPI();
        System.out.println("Valor de PI: " + pi);
    }
    
    // Metodo sin parametros y con retorno
    public static double obtenerPI() {
        return 3.1416;
    }
}
