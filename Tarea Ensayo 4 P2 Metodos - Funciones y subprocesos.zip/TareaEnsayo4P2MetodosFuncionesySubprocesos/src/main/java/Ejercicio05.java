/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio05 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese el primer numero: ");
            double a = sc.nextDouble();
            System.out.print("Ingrese el segundo numero: ");
            double b = sc.nextDouble();
            operaciones(a, b);
        }
    }
    
    // Metodo con parametros y sin retorno
    public static void operaciones(double a, double b) {
        System.out.println("Suma: " + (a + b));
        System.out.println("Resta: " + (a - b));
        System.out.println("Multiplicacion: " + (a * b));
        if (b != 0) {
            System.out.println("Division: " + (a / b));
        } else {
            System.out.println("Division: No se puede dividir entre cero.");
        }
    }
}