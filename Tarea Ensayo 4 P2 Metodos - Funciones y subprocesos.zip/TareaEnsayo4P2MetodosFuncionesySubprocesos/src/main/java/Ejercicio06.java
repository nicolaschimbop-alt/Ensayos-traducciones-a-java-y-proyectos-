/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
public class Ejercicio06 {
    public static void main(String[] args) {
        int numero = obtenerNumero();
        System.out.println("Numero aleatorio: " + numero);
    }
    
    // Metodo sin parametros y con retorno
    public static int obtenerNumero() {
        return (int) (Math.random() * 100) + 1;
    }
}
