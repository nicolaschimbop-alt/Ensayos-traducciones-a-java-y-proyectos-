/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio02 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese el primer numero entero: ");
            int num1 = sc.nextInt();
            
            System.out.print("Ingrese el segundo numero entero: ");
            int num2 = sc.nextInt();
            
            int suma = num1 + num2;
            int resta = num1 - num2;
            int multiplicacion = num1 * num2;
            int division = num1 / num2;   // división entera
            int residuo = num1 % num2;
            
            System.out.println("\n--- Resultados ---");
            System.out.println("Suma: " + suma);
            System.out.println("Resta: " + resta);
            System.out.println("Multiplicacion: " + multiplicacion);
            System.out.println("Division (entera): " + division);
            System.out.println("Residuo: " + residuo);
        }
    }
}