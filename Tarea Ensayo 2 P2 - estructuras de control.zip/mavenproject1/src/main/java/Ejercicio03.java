/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio03 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese su edad: ");
            int edad = sc.nextInt();
            
            if (edad >= 18) {
                System.out.println("Es mayor de edad.");
            }
        }
    }
}
