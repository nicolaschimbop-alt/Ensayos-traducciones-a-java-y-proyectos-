/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio01 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese su nombre: ");
            String nombre = sc.nextLine();
            
            System.out.print("Ingrese su edad: ");
            int edad = sc.nextInt();
            sc.nextLine(); // limpiar buffer
            
            System.out.print("Ingrese su carrera: ");
            String carrera = sc.nextLine();
            
            System.out.print("Ingrese su estatura (en metros): ");
            double estatura = sc.nextDouble();
            
            System.out.println("\n--- Datos ingresados ---");
            System.out.println("Nombre: " + nombre);
            System.out.println("Edad: " + edad);
            System.out.println("Carrera: " + carrera);
            System.out.println("Estatura: " + estatura + " m");
        }
    }
}
