/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio07 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int contador = 0;
            int suma = 0;
            int numero;
            
            System.out.println("Ingrese numeros positivos (negativo para terminar):");
            
            while (true) {
                System.out.print("Numero: ");
                numero = sc.nextInt();
                
                if (numero < 0) {
                    break; // sale del bucle
                }
                
                contador++;
                suma += numero;
            }
            
            System.out.println("\n--- Resultados ---");
            System.out.println("Cantidad de numeros ingresados (sin contar el negativo): " + contador);
            System.out.println("Suma total: " + suma);
        }
    }
}
