/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Ingrese 10 numeros:");
            
            // Inicializar con el primer número
            System.out.print("Numero 1: ");
            int numero = sc.nextInt();
            int mayor = numero;
            int menor = numero;
            
            for (int i = 2; i <= 10; i++) {
                System.out.print("Numero " + i + ": ");
                numero = sc.nextInt();
                
                if (numero > mayor) {
                    mayor = numero;
                }
                if (numero < menor) {
                    menor = numero;
                }
            }
            
            System.out.println("\n--- Resultados ---");
            System.out.println("Numero mayor: " + mayor);
            System.out.println("Numero menor: " + menor);
        }
    }
}