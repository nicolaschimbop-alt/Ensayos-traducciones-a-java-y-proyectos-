/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio06 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Ingrese un numero del 1 al 7: ");
            int numero = sc.nextInt();
            
            switch (numero) {
                case 1 -> System.out.println("Lunes");
                case 2 -> System.out.println("Martes");
                case 3 -> System.out.println("Miercoles");
                case 4 -> System.out.println("Jueves");
                case 5 -> System.out.println("Viernes");
                case 6 -> System.out.println("Sabado");
                case 7 -> System.out.println("Domingo");
                default -> System.out.println("Numero invalido. Debe ser entre 1 y 7.");
            }
        }
    }
}