/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio08 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            String clave;
            final String CLAVE_CORRECTA = "java2026";
            
            do {
                System.out.print("Ingrese la contraseña: ");
                clave = sc.nextLine();
            } while (!clave.equals(CLAVE_CORRECTA));
            
            System.out.println("Acceso concedido.");
        }
    }
}
