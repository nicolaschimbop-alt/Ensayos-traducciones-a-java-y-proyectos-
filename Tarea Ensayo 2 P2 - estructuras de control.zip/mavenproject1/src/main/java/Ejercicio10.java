/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int suma = 0;
            int cantidad = 10;
            
            System.out.println("Ingrese 10 numeros enteros:");
            for (int i = 1; i <= cantidad; i++) {
                System.out.print("Numero " + i + ": ");
                int num = sc.nextInt();
                suma += num;
            }
            
            double promedio = (double) suma / cantidad;
            
            System.out.println("\n--- Resultados ---");
            System.out.println("Suma: " + suma);
            System.out.println("Promedio: " + promedio);
        }
    }
}