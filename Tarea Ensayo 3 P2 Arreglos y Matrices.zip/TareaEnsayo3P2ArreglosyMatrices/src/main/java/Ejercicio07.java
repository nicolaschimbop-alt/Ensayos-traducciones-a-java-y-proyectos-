/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio07 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[][] matriz = new int[4][4];
            int suma = 0;
            
            System.out.println("Ingrese los valores para la matriz 4×4:");
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    System.out.print("Posicion [" + i + "][" + j + "]: ");
                    matriz[i][j] = sc.nextInt();
                    suma += matriz[i][j];
                }
            }
            
            System.out.println("\n--- Matriz ingresada ---");
            for (int i = 0; i < 4; i++) {
                for (int j = 0; j < 4; j++) {
                    System.out.print(matriz[i][j] + " ");
                }
                System.out.println();
            }

            System.out.println("\nSuma total de los elementos: " + suma);
        }
    }
}
