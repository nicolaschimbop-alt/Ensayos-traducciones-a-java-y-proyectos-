/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio05 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[] numeros = new int[12];
            
            System.out.println("Ingrese 12 numeros positivos:");
            for (int i = 0; i < 12; i++) {
                int numero;
                do {
                    System.out.print("Numero " + (i + 1) + " (positivo): ");
                    numero = sc.nextInt();
                    if (numero <= 0) {
                        System.out.println("Debe ingresar un numero positivo.");
                    }
                } while (numero <= 0);
                
                numeros[i] = numero + i;
            }
            
            System.out.println("\n--- Arreglo modificado ---");
            for (int i = 0; i < 12; i++) {
                System.out.println("Posicion " + i + ": " + numeros[i]);
            }
        }
    }
}