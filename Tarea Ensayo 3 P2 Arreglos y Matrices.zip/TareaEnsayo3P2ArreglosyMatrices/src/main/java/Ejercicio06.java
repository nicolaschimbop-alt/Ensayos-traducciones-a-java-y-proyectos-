/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio06 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[][] matriz = new int[3][4];
            
            System.out.println("Ingrese los valores para la matriz 3×4:");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 4; j++) {
                    System.out.print("Posicion [" + i + "][" + j + "]: ");
                    matriz[i][j] = sc.nextInt();
                }
            }
            
            System.out.println("\n--- Matriz resultante ---");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 4; j++) {
                    System.out.print(matriz[i][j] + " ");
                }
                System.out.println();
            }
        }
    }
}
