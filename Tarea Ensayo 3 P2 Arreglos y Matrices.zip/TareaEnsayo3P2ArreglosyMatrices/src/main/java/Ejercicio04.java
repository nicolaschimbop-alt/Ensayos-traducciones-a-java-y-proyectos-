/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio04 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[] numeros = new int[20];
            int contPares = 0, contImpares = 0;
            int sumaPares = 0, sumaImpares = 0;
            System.out.println("Ingrese 20 numeros enteros:");
            for (int i = 0; i < 20; i++) {
                System.out.print("Numero " + (i + 1) + ": ");
                numeros[i] = sc.nextInt();
                
                if (numeros[i] % 2 == 0) {
                    contPares++;
                    sumaPares += numeros[i];
                } else {
                    contImpares++;
                    sumaImpares += numeros[i];
                }
            }   System.out.println("\n--- Resultados ---");
            System.out.println("Cantidad de pares: " + contPares);
            System.out.println("Cantidad de impares: " + contImpares);
            System.out.println("Suma de pares: " + sumaPares);
            System.out.println("Suma de impares: " + sumaImpares);
        }
    }
}
