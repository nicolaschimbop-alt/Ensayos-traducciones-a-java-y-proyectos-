/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[][] matriz = new int[3][5];
            
            System.out.println("Ingrese los valores para la matriz 3×5:");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    System.out.print("Posicion [" + i + "][" + j + "]: ");
                    int valor = sc.nextInt();
                    // Se suman los indices de fila y columna
                    matriz[i][j] = valor + i + j;
                }
            }
            
            System.out.println("\n--- Matriz resultante ---");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 5; j++) {
                    System.out.print(matriz[i][j] + " ");
                }
                System.out.println();
            }
        }
    }
}
