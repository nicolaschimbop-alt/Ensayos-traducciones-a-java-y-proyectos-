/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio01 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[] numeros = new int[10];
            
            System.out.println("Ingrese 10 numeros enteros:");
            for (int i = 0; i < 10; i++) {
                System.out.print("Numero " + (i + 1) + ": ");
                numeros[i] = sc.nextInt();
            }
            
            System.out.println("\n--- Valores almacenados ---");
            for (int i = 0; i < 10; i++) {
                // Se suma 1 para mostrar la posicion contando desde 1
                System.out.println("Posicion " + (i + 1) + ": " + numeros[i]);
            }
        }
    }
}