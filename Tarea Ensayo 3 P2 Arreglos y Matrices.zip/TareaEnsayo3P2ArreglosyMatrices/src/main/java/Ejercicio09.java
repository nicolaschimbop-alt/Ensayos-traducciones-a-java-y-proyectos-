/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio09 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[][] matriz = new int[5][5];
            System.out.println("Ingrese los valores para la matriz 5×5:");
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    System.out.print("Posicion [" + i + "][" + j + "]: ");
                    matriz[i][j] = sc.nextInt();
                }
            }   int mayor = matriz[0][0];
            int menor = matriz[0][0];
            int filaMayor = 0, colMayor = 0;
            int filaMenor = 0, colMenor = 0;
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    if (matriz[i][j] > mayor) {
                        mayor = matriz[i][j];
                        filaMayor = i;
                        colMayor = j;
                    }
                    if (matriz[i][j] < menor) {
                        menor = matriz[i][j];
                        filaMenor = i;
                        colMenor = j;
                    }
                }
            }   System.out.println("\n--- Matriz ingresada ---");
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    System.out.print(matriz[i][j] + " ");
                }
                System.out.println();
            }   System.out.println("\n--- Resultados ---");
            System.out.println("Mayor valor: " + mayor + " en posicion [" + filaMayor + "][" + colMayor + "]");
            System.out.println("Menor valor: " + menor + " en posicion [" + filaMenor + "][" + colMenor + "]");
        }
    }
}