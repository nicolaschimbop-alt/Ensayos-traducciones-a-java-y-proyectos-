/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio03 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            int[] numeros = new int[15];
            
            System.out.println("Ingrese 15 numeros enteros:");
            for (int i = 0; i < 15; i++) {
                System.out.print("Numero " + (i + 1) + ": ");
                numeros[i] = sc.nextInt();
            }
            
            int mayor = numeros[0];
            int menor = numeros[0];
            int posMayor = 0; // indice en el arreglo (base 0)
            int posMenor = 0;
            
            for (int i = 1; i < 15; i++) {
                if (numeros[i] > mayor) {
                    mayor = numeros[i];
                    posMayor = i;
                }
                if (numeros[i] < menor) {
                    menor = numeros[i];
                    posMenor = i;
                }
            }
            
            System.out.println("\n--- Resultados ---");
            // Se suma 1 para mostrar posicion contando desde 1
            System.out.println("Numero mayor: " + mayor + " en posicion " + (posMayor + 1));
            System.out.println("Numero menor: " + menor + " en posicion " + (posMenor + 1));
        }
    }
}