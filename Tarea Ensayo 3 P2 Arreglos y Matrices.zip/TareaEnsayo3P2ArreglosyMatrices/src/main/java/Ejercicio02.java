/**
 * @author [Mathias Nicolas Chimbo Pereira]
 */
import java.util.Scanner;

public class Ejercicio02 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            double[] numeros = new double[10];
            double suma = 0;
            
            System.out.println("Ingrese 10 numeros reales:");
            for (int i = 0; i < 10; i++) {
                System.out.print("Numero " + (i + 1) + ": ");
                numeros[i] = sc.nextDouble();
                suma += numeros[i];
            }
            
            double promedio = suma / 10;
            
            System.out.println("\n--- Resultados ---");
            System.out.println("Suma total: " + suma);
            System.out.println("Promedio: " + promedio);
        }
    }
}